module.exports = {
    ...require('./auth'),
    ...require('./home'),

}