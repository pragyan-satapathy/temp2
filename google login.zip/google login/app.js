const dotenv = require('dotenv')
dotenv.config({ path: ".env" })
const express = require("express")
const session = require('express-session')
const MongoStore = require('connect-mongo');

const { connectDB } = require("./config")
const { routerAuth } = require("./routes")
const passport = require('passport')
const { passportConfig } = require('./config')

// express app
const app = express()

// connect to mongodb
connectDB();

// call passport
passportConfig(passport)

// session middleware
app.use(session({
    secret: 'keyboard cat',
    resave: false,
    saveUninitialized: false,
    // don't logout even after app restart
    store: MongoStore.create({ mongoUrl: process.env.MONGO_URI })
}))

// passport middleware
app.use(passport.initialize())
app.use(passport.session())


// app.get('/', (req,res) => {
//     res.send('home page')
// })

app.use('/auth',routerAuth)

app.listen(process.env.PORT, () => {
    console.log("running on port:",process.env.PORT);
})