const nodemailer = require('nodemailer');


let mailTransporter = nodemailer.createTransport({
	service: 'gmail',
	auth: {
		user: 'pragyans248@gmail.com',
		pass: '******************'
	}
});

let mailDetails = {
	from: 'pragyans248@gmail.com',
	to: 'pragyan.satapathy@glosity.club',
	subject: 'Test mail',
	text: 'Node.js testing mail'
};

mailTransporter.sendMail(mailDetails, function(err, data) {
	if(err) {
		console.log('err');
	} else {
		console.log('Email sent successfully');
	}
});