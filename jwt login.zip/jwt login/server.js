const dotenv = require('dotenv')
dotenv.config({ path: ".env" })
const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')
const bcrypt = require('bcryptjs')
const jwt = require('jsonwebtoken')

const { connectDB } = require("./database/db")
const User = require('./model/user')

const JWT_SECRET = '!!!!!!DFS^%E$@#$DRSGFHjfuihernjjfsgg5g453g356gruy4hjsn)()UIJBDH4325GTD^&%^^%$#$()*^^%#sdfwegfey&gfr4352'

const app = express()


//middleware to decode the body(req.body)
app.use(bodyParser.json())


// connect to mogodb
connectDB()

app.post('/api/register', async (req, res) => {
    // get username and password from body
    const {username, password } = req.body
    console.log(password)

    // encrypt password
    // bcrypt.hash(password, salt)
    // salt: how many iteration of bcrypt you wanna run
    // return a encrypted password of fixed length
    const hashedPassword = await bcrypt.hash(password, 10);

    try {
        const response = await User.create({
            username,
            password: hashedPassword
        })
        console.log("user created successfully", response)
    } catch (error) {
        console.log(JSON.stringify(error));
        return res.json({ status: 'error' })
    }
    
    res.json({ status: 'ok' })
})


app.post('/api/login', async (req, res) => {
	const { username, password } = req.body
    
	const user = await User.findOne({ username }).lean()

	if (!user) {
		return res.json({ status: 'error', error: 'Invalid username/password' })
	}

    // comapare encrypted password to normal password
	if (await bcrypt.compare(password, user.password)) {
        // jwt.sign(payload, secretOrPrivateKey)
        // payload is public and can be accessible to anyone
        // so, don't put any secret thing inside payload
        // secretOrPrivateKey(here JWT_SECRET) is not accessible
        // make sure, no-one should no about your JWT_SECRET (if get access then can manipulate data easily)
		const token = jwt.sign(
			{
				id: user._id,
				username: user.username
			},
			JWT_SECRET
		)

		return res.json({ status: 'ok', data: token })
	}

	res.json({ status: 'error', error: 'Invalid username/password' })
})

app.post('/api/change-password', async (req, res) => {
	const { token, newpassword: plainTextPassword } = req.body

	try {
        // each time verify token before doing anything
		const user = jwt.verify(token, JWT_SECRET)

		const _id = user.id

		const password = await bcrypt.hash(plainTextPassword, 10)

		await User.updateOne(
			{ _id },
			{
				$set: { password }
			}
		)
		res.json({ status: 'ok' })
	} catch (error) {
		console.log(error)
		res.json({ status: 'error' })
	}
})


app.listen(3000, () => {
    console.log('running on port: 3000');
})